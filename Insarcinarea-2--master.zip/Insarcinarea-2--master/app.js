document.addEventListener('DOMContentLoaded', () =>{     

let n = prompt();
         switch (n) {
     
		case '1':
            console.log('unu');
              break;
              case '2':
          console.log('doi');
            break;
            case '3':
          console.log('trei');
            break;
            case '4':
          console.log('patru');
            break;
            case '5':
          console.log('cinci');
            break;
            case '6':
          console.log('sase');
            break;
            case '7':
          console.log('sapte');
            break;
            case '8':
          console.log('opt');
            break;
            case '9':
            console.log('noua');
              break; 
       default: console.log('Nu este cifra')
         }
})

        